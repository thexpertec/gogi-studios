import { Router } from "express";
import { db, workSectionsTable, workSubCategoriesTable } from "../lib/db";
import { eq, asc, max } from "drizzle-orm";

const router = Router();
const COOKIE_NAME = "gogi_admin_session";
const COOKIE_VALUE = "authenticated";

function isAdmin(req: any): boolean {
  return req.signedCookies?.[COOKIE_NAME] === COOKIE_VALUE;
}
function isValidSlug(s: string): boolean {
  return /^[a-z0-9-]+$/.test(s) && s.length > 0 && s.length <= 100;
}

/** GET /api/work-sections — public
 *  ?domain=work (default) | ?domain=services | … | ?domain=all (admin)
 */
router.get("/work-sections", async (req, res) => {
  const domainParam = (req.query.domain as string | undefined) ?? "work";
  try {
    const [sections, subCats] = await Promise.all([
      db.select().from(workSectionsTable).orderBy(asc(workSectionsTable.sortOrder)),
      db.select().from(workSubCategoriesTable).orderBy(asc(workSubCategoriesTable.sortOrder)),
    ]);
    const filtered = domainParam === "all" ? sections : sections.filter((s) => (s.domain ?? "work") === domainParam);
    const result = filtered.map((s) => ({
      slug: s.slug,
      label: s.label,
      domain: s.domain ?? "work",
      subCategories: subCats
        .filter((sc) => sc.sectionSlug === s.slug)
        .map((sc) => ({ slug: sc.slug, label: sc.label, description: sc.description ?? null, parentSlug: sc.parentSlug ?? null })),
    }));
    res.json(result);
  } catch {
    res.status(500).json({ error: "Failed to load work sections." });
  }
});

const VALID_DOMAINS = new Set(["work", "services", "awards", "news", "books", "shop"]);

/** POST /api/work-sections — admin; { slug, label, domain? } */
router.post("/work-sections", async (req, res) => {
  if (!isAdmin(req)) { res.status(401).json({ ok: false, error: "Unauthorized." }); return; }
  const { slug, label, domain } = req.body as { slug?: string; label?: string; domain?: string };
  if (!slug?.trim() || !label?.trim()) { res.status(400).json({ ok: false, error: "slug and label are required." }); return; }
  if (!isValidSlug(slug.trim())) { res.status(400).json({ ok: false, error: "Invalid slug." }); return; }
  const domainVal = (domain && VALID_DOMAINS.has(domain)) ? domain : "work";

  try {
    const [{ maxOrder }] = await db.select({ maxOrder: max(workSectionsTable.sortOrder) }).from(workSectionsTable);
    const [section] = await db.insert(workSectionsTable).values({ slug: slug.trim(), label: label.trim(), sortOrder: (maxOrder ?? -1) + 1, domain: domainVal }).returning();
    res.json({ ok: true, section: { ...section, domain: section.domain, subCategories: [] } });
  } catch (err: any) {
    if (err?.code === "23505") { res.status(409).json({ ok: false, error: "Slug already exists." }); return; }
    res.status(500).json({ ok: false, error: "Failed to create section." });
  }
});

/** PATCH /api/work-sections/:slug — admin; { label } */
router.patch("/work-sections/:slug", async (req, res) => {
  if (!isAdmin(req)) { res.status(401).json({ ok: false, error: "Unauthorized." }); return; }
  const { slug } = req.params;
  const { label } = req.body as { label?: string };
  if (!label?.trim()) { res.status(400).json({ ok: false, error: "label is required." }); return; }

  try {
    const [updated] = await db.update(workSectionsTable).set({ label: label.trim() }).where(eq(workSectionsTable.slug, slug)).returning();
    if (!updated) { res.status(404).json({ ok: false, error: "Section not found." }); return; }
    res.json({ ok: true, section: updated });
  } catch {
    res.status(500).json({ ok: false, error: "Failed to update section." });
  }
});

/** DELETE /api/work-sections/:slug — admin */
router.delete("/work-sections/:slug", async (req, res) => {
  if (!isAdmin(req)) { res.status(401).json({ ok: false, error: "Unauthorized." }); return; }
  const { slug } = req.params;

  try {
    const deleted = await db.delete(workSectionsTable).where(eq(workSectionsTable.slug, slug)).returning();
    if (!deleted.length) { res.status(404).json({ ok: false, error: "Section not found." }); return; }
    res.json({ ok: true });
  } catch {
    res.status(500).json({ ok: false, error: "Failed to delete section." });
  }
});

/** PATCH /api/work-sections/:slug/sub-categories/:subSlug — admin; { label } */
router.patch("/work-sections/:slug/sub-categories/:subSlug", async (req, res) => {
  if (!isAdmin(req)) { res.status(401).json({ ok: false, error: "Unauthorized." }); return; }
  const { subSlug } = req.params;
  const { label, description } = req.body as { label?: string; description?: string | null };
  if (label !== undefined && !label?.trim()) { res.status(400).json({ ok: false, error: "label is required." }); return; }
  if (label === undefined && description === undefined) { res.status(400).json({ ok: false, error: "Nothing to update." }); return; }

  const patch: Record<string, unknown> = {};
  if (label !== undefined) patch.label = label.trim();
  if (description !== undefined) patch.description = description?.trim() ? description.trim() : null;

  try {
    const [updated] = await db
      .update(workSubCategoriesTable)
      .set(patch)
      .where(eq(workSubCategoriesTable.slug, subSlug))
      .returning();
    if (!updated) { res.status(404).json({ ok: false, error: "Sub-category not found." }); return; }
    res.json({ ok: true, subCategory: updated });
  } catch {
    res.status(500).json({ ok: false, error: "Failed to update sub-category." });
  }
});

/** POST /api/work-sections/:slug/sub-categories — admin; { slug, label, parentSlug? } */
router.post("/work-sections/:slug/sub-categories", async (req, res) => {
  if (!isAdmin(req)) { res.status(401).json({ ok: false, error: "Unauthorized." }); return; }
  const { slug: sectionSlug } = req.params;
  const { slug, label, parentSlug } = req.body as { slug?: string; label?: string; parentSlug?: string | null };
  if (!slug?.trim() || !label?.trim()) { res.status(400).json({ ok: false, error: "slug and label are required." }); return; }
  if (!isValidSlug(slug.trim())) { res.status(400).json({ ok: false, error: "Invalid slug." }); return; }

  try {
    const [{ maxOrder }] = await db.select({ maxOrder: max(workSubCategoriesTable.sortOrder) }).from(workSubCategoriesTable).where(eq(workSubCategoriesTable.sectionSlug, sectionSlug));
    const [sub] = await db.insert(workSubCategoriesTable).values({
      slug: slug.trim(), label: label.trim(), sectionSlug,
      parentSlug: parentSlug ?? null, sortOrder: (maxOrder ?? -1) + 1,
    }).returning();
    res.json({ ok: true, subCategory: sub });
  } catch (err: any) {
    if (err?.code === "23505") { res.status(409).json({ ok: false, error: "Slug already exists." }); return; }
    res.status(500).json({ ok: false, error: "Failed to create sub-category." });
  }
});

/** DELETE /api/work-sections/:slug/sub-categories/:subSlug — admin */
router.delete("/work-sections/:slug/sub-categories/:subSlug", async (req, res) => {
  if (!isAdmin(req)) { res.status(401).json({ ok: false, error: "Unauthorized." }); return; }
  const { subSlug } = req.params;

  try {
    const deleted = await db.delete(workSubCategoriesTable).where(eq(workSubCategoriesTable.slug, subSlug)).returning();
    if (!deleted.length) { res.status(404).json({ ok: false, error: "Sub-category not found." }); return; }
    res.json({ ok: true });
  } catch {
    res.status(500).json({ ok: false, error: "Failed to delete sub-category." });
  }
});

export default router;
