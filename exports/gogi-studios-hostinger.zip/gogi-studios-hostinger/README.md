# Gogi Studios — Deployment Package (Hostinger)

Full-stack TypeScript project:

- **Frontend:** React 19 + Vite 7 (in `artifacts/gogi-studios`)
- **Backend:** Express 5 on Node.js (in `artifacts/api-server`)
- **Shared code:** database schema and API types (in `lib/`)
- **Database:** PostgreSQL (via Drizzle ORM)
- **File storage:** Cloudflare R2 (photos and logo)

In production, **one Node.js process** runs everything: the Express server
serves the built frontend files AND handles all `/api/...` routes.

---

## Requirements

| Requirement | Version |
|---|---|
| Node.js | **20.x, 22.x, or 24.x** (LTS 22 recommended) |
| pnpm | 9 or newer (`npm install -g pnpm`) |
| PostgreSQL | 15 or newer |

---

## 1. Install dependencies

```bash
pnpm install --no-frozen-lockfile
```

(`--no-frozen-lockfile` is needed because this package is a trimmed export of a
larger workspace; pnpm will reconcile the lock file on first install.)

## 2. Set up the database

Create a PostgreSQL database, then import the provided export
(`gogi-database-export.sql`, shipped alongside this ZIP):

```bash
psql "postgresql://USER:PASSWORD@HOST:5432/DBNAME" -f gogi-database-export.sql
```

This creates **all tables and data** (services, testimonials, work sections,
gallery items, settings, content overrides, catalog).

Alternative (schema only, no data): set `DATABASE_URL` in your environment and run:

```bash
pnpm run db:push
```

## 3. Configure environment variables

Copy `.env.example` to `.env` and fill in every value (see the comments in
that file). Required at runtime:

| Variable | Purpose |
|---|---|
| `PORT` | Port the server listens on |
| `NODE_ENV` | Must be `production` |
| `DATABASE_URL` | PostgreSQL connection string |
| `SESSION_SECRET` | Random string that signs admin login cookies — generate a fresh one |
| `ADMIN_PASSWORD` | Password for the site's admin login |
| `R2_ACCOUNT_ID` | Cloudflare R2 account ID |
| `R2_ACCESS_KEY_ID` | Cloudflare R2 access key |
| `R2_SECRET_ACCESS_KEY` | Cloudflare R2 secret key |
| `R2_BUCKET_NAME` | Cloudflare R2 bucket name |
| `LOG_LEVEL` | *(optional)* log verbosity |
| `STATIC_DIR` | *(optional)* custom path to the built frontend |

> Note: the Express server reads variables from the process environment. If
> your host doesn't load `.env` automatically, either configure the variables
> in the Hostinger panel, or start with `node --env-file=.env ...`
> (see "Start" below).

## 4. Build

```bash
pnpm run build
```

This:
1. Builds the React frontend into `artifacts/gogi-studios/dist/public`
2. Bundles the Express server into `artifacts/api-server/dist/index.mjs`

## 5. Start

```bash
pnpm run start
```

Or directly (useful for Hostinger's Node.js app settings, and loads `.env`):

```bash
node --env-file=.env --enable-source-maps artifacts/api-server/dist/index.mjs
```

The server:
- serves the website at `/`
- handles all API routes under `/api/...` (health check: `GET /api/healthz`)
- serves uploaded images from R2 via `/api/content-images/...`, `/api/static-images/...`, `/api/logo`

For Hostinger's Node.js hosting, set the **startup file** to
`artifacts/api-server/dist/index.mjs` (after running the build), or run the
app under a process manager such as pm2:

```bash
pm2 start artifacts/api-server/dist/index.mjs --name gogi-studios --node-args="--env-file=.env"
```

---

## Project layout

```
artifacts/gogi-studios/   React + Vite frontend (src/, vite.config.ts, tsconfig.json)
artifacts/api-server/     Express backend (src/routes/ = API + upload routes, build.mjs)
lib/db/                   Drizzle database schema (src/schema/) + drizzle.config.ts
lib/api-zod/              Shared request/response validation schemas
lib/api-client-react/     Shared API client for the frontend
lib/api-spec/             API specification
pnpm-workspace.yaml       Workspace + dependency catalog
pnpm-lock.yaml            Lock file
tsconfig.base.json        Shared TypeScript configuration
.env.example              All required environment variable names (no values)
```

## Database schema & migrations

- Schema source of truth: `lib/db/src/schema/` (Drizzle ORM, PostgreSQL)
- `lib/db/drizzle.config.ts` + `pnpm run db:push` applies the schema to the
  database pointed to by `DATABASE_URL`
- The full export `gogi-database-export.sql` (schema **and** data) is provided
  as a separate file next to this ZIP
- The server also self-heals the `content_overrides` table at startup

## Admin features

Log in via the site's admin login (uses `ADMIN_PASSWORD`). Admin sessions are
signed cookies (`SESSION_SECRET`). Admins can edit site text, upload/replace
photos and the logo (stored in Cloudflare R2), and manage services,
testimonials, and gallery items.

## Security notes

- This package contains **no secrets** — `.env.example` lists names only
- Generate a **new** `SESSION_SECRET` for production; do not reuse dev values
- Use a strong `ADMIN_PASSWORD`
- If your PostgreSQL host requires SSL, append `?sslmode=require` to `DATABASE_URL`
