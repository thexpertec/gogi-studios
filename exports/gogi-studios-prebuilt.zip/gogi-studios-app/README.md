# Gogi Studios — Pre-built Deployment Bundle

This bundle is ALREADY BUILT. There is no build step, no pnpm, and no
workspace — it works with plain npm.

## Requirements
- Node.js 20.x, 22.x, or 24.x (22 LTS recommended)
- A PostgreSQL database (e.g. Supabase, Neon, or any managed PostgreSQL)

## Deploy (Hostinger Node.js app / any Node host)

1. Upload and extract this bundle
2. Install the two runtime dependencies:

       npm install

3. Set the environment variables listed in `.env.example`
4. Start command / startup file:

       npm start
       # or directly:
       node --enable-source-maps index.mjs

The single Node.js process serves the website at `/` (from `public/`) and all
API routes under `/api/...` (health check: `GET /api/healthz`).

## Database
Import the provided `gogi-database-export.sql` into your PostgreSQL database
(schema + data):

    psql "YOUR_DATABASE_URL" -f gogi-database-export.sql

(For Supabase you can also paste it into the SQL Editor.)

## Environment variables (see .env.example)
PORT, NODE_ENV=production, DATABASE_URL, SESSION_SECRET, ADMIN_PASSWORD,
R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME
Optional: LOG_LEVEL, STATIC_DIR
